import { Component, OnInit } from '@angular/core';
import { HttpService } from './http.service';

@Component({
    selector: 'app-root',
    templateUrl: './app.component.html',
    styleUrls: ['./app.component.css']
})

export class AppComponent implements OnInit {
    title = 'MEAN';
    gold: number;
    name: string;
    action: string;
    log: Array<any>;

    constructor(private _httpService: HttpService) { }
    // ngOnInit will run when the component is initialized, after the constructor method.
    ngOnInit() {
        this.gold = 0;
    }
    randNumRange(min, max) {
        return Math.floor(Math.random() * (max - min)) + min;
    }
    onClickPlace(id: number) {
        if (id == 1) {
            var gold = this.randNumRange(2, 5);
            var myActivity = `You earned ${gold} gold at farm!`;
        } else if (id == 2) {
            gold = this.randNumRange(5, 10);
            myActivity = `You earned ${gold} gold at cave!`;
        } else if (id == 3) {
            gold = this.randNumRange(7, 15);
            myActivity = `You earned ${gold} gold at house!`;
        } else {
            gold = this.randNumRange(-100, 100);
            myActivity = `You earned ${gold} gold at casino!`;
        }

        if (!(this.log)) {
            this.log = [];
        }
        this.log.push(myActivity);
        console.log(`--> ${this.log}`);

        let data = {
            activity: myActivity
        }
        let observable = this._httpService.updateActivity(data);
        observable.subscribe(data => {
            console.log(data);
        })
    }
}
